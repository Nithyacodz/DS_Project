-- Schema creation
CREATE SCHEMA `assignment` ;
-- Import date to MySQL
-- 1.Create a new table named 'bajaj1' containing the date, close price, 20 Day MA and 50 Day MA.
create table bajaj1
select	str_to_date(`date`, '%d-%M-%Y') as 'Date'	, 
		`Close Price` as 'Close Price',
		if(row_number() over()  > 19,cast(avg(`close price`) over (  rows between 19  preceding and current row) as decimal(10,2)),NULL) as '20 Day MA',
        if(row_number() over()  > 49,cast(avg(`close price`) over (  rows between 49  preceding and current row) as decimal(10,2)),NULL) as '50 Day MA'	
from bajaj_auto;
-- For Eicher
create table eicher1
select	str_to_date(`date`, '%d-%M-%Y') as 'Date'	, 
		`Close Price` as 'Close Price',
		if(row_number() over()  > 19,cast(avg(`close price`) over (  rows between 19  preceding and current row) as decimal(10,2)),NULL) as '20 Day MA',
        if(row_number() over()  > 49,cast(avg(`close price`) over (  rows between 49  preceding and current row) as decimal(10,2)),NULL) as '50 Day MA'	
from eicher_motors;
-- For Hero Motocorp
create table hero1
select	str_to_date(`date`, '%d-%M-%Y') as 'Date'	, 
		`Close Price` as 'Close Price',
		if(row_number() over()  > 19,cast(avg(`close price`) over (  rows between 19  preceding and current row) as decimal(10,2)),NULL) as '20 Day MA',
        if(row_number() over()  > 49,cast(avg(`close price`) over (  rows between 49  preceding and current row) as decimal(10,2)),NULL) as '50 Day MA'	
from hero_motocorp;
-- For Infosys
create table infosys1
select	str_to_date(`date`, '%d-%M-%Y') as 'Date'	, 
		`Close Price` as 'Close Price',
		if(row_number() over()  > 19,cast(avg(`close price`) over (  rows between 19  preceding and current row) as decimal(10,2)),NULL) as '20 Day MA',
        if(row_number() over()  > 49,cast(avg(`close price`) over (  rows between 49  preceding and current row) as decimal(10,2)),NULL) as '50 Day MA'	
from infosys;
-- For TCS
create table tcs1
select	str_to_date(`date`, '%d-%M-%Y') as 'Date'	, 
		`Close Price` as 'Close Price',
		if(row_number() over()  > 19,cast(avg(`close price`) over (  rows between 19  preceding and current row) as decimal(10,2)),NULL) as '20 Day MA',
        if(row_number() over()  > 49,cast(avg(`close price`) over (  rows between 49  preceding and current row) as decimal(10,2)),NULL) as '50 Day MA'	
from tcs;
-- For tvs motors
create table tvs1
select	str_to_date(`date`, '%d-%M-%Y') as 'Date'	, 
		`Close Price` as 'Close Price',
		if(row_number() over()  > 19,cast(avg(`close price`) over (  rows between 19  preceding and current row) as decimal(10,2)),NULL) as '20 Day MA',
        if(row_number() over()  > 49,cast(avg(`close price`) over (  rows between 49  preceding and current row) as decimal(10,2)),NULL) as '50 Day MA'	
from tvs_motors;

---2. Create a master table containing the date and close price of all the six stocks.
create table master_date_closeprice
SELECT 	t1.date AS 'Date',
		t1.`Close Price` AS 'Bajaj',
		t4.`Close Price` as 'TCS',
		t5.`Close Price` as 'TVS',
		t3.`Close Price` AS 'Infosys',
		t2.`Close Price` AS 'Eicher',           
		t6.`Close Price` as 'Hero'		
FROM bajaj1 t1
INNER JOIN	eicher1 t2
ON	t1.date = t2.date
inner join infosys1 t3
ON	t1.date = t3.date
inner join tcs1 t4
ON t1.date = t4.date
inner join tvs1 t5
ON t1.date = t5.date
inner join hero1 t6
on t1.date = t6.date ;

---3. se the table created in Part(1) to generate buy and sell signal.
--For Bajaj
create table bajaj2
select 	Date, 
		`Close Price`, 
		case 
			when `20 Day MA` > `50 Day MA` then "BUY" 
			when `20 Day MA` < `50 Day MA` then "SELL"
			else "HOLD" 
		end   as 'Signal' 
from bajaj1;
--- For eicher
create table eicher2
select 	Date, 
		`Close Price`, 		
		case 
			when `20 Day MA` > `50 Day MA` then "BUY" 
			when `20 Day MA` < `50 Day MA` then "SELL"
			else "HOLD" 
		end   as 'Signal' 
from eicher1;
--- For Hero
create table hero2
select 	Date, 
		`Close Price`, 		
		case 
			when `20 Day MA` > `50 Day MA` then "BUY" 
			when `20 Day MA` < `50 Day MA` then "SELL"
			else "HOLD" 
		end   as 'Signal' 
from hero1;
---For Infosys
create table infosys2
select 	Date, 
		`Close Price`, 		
		case 
			when `20 Day MA` > `50 Day MA` then "BUY" 
			when `20 Day MA` < `50 Day MA` then "SELL"
			else "HOLD" 
		end   as 'Signal' 
from infosys1;
--- For TCS
create table tcs2
select 	Date, 
		`Close Price`, 		
		case 
			when `20 Day MA` > `50 Day MA` then "BUY" 
			when `20 Day MA` < `50 Day MA` then "SELL"
			else "HOLD" 
		end   as 'Signal' 
from tcs1;
---For tvs
create table tvs2
select 	Date, 
		`Close Price`, 		
		case 
			when `20 Day MA` > `50 Day MA` then "BUY" 
			when `20 Day MA` < `50 Day MA` then "SELL"
			else "HOLD" 
		end   as 'Signal' 
from tvs1;

---4. Create a User defined function, that takes the date as input and returns the signal for that particular day (Buy/Sell/Hold) for the Bajaj stock.
-- User Defined function return_signal:: START
drop function if exists return_signal;

DELIMITER $$
CREATE FUNCTION `return_signal`( dt date ) 
	RETURNS char(10) 
    DETERMINISTIC
begin
    declare ret_signal char(10);
    declare short_term float(10, 2);
    declare long_term float(10, 2);
    select `20 Day MA`,
			`50 Day MA`
	into short_term, 
		 long_term
	from bajaj1
	where date = dt;

    if short_term > long_term then
		set ret_signal ='BUY';
	elseif 	short_term < long_term then
		set ret_signal ='SELL';
	else
		set ret_signal ='HOLD';
	end if;

	return ret_signal;
end
$$

select return_signal('2018-07-03') as Signal1;

-- User Defined function return_signal:: END

